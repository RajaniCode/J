Maintainer
========

- Mariano Reingart <reingart@gmail.com>


Contributors
========

- Dean Gardiner <fuzeman91@gmail.com> @fuzeman
- Piotr Staroszczyk <piotr.staroczyk@get24.org> @oczkers
- Rui Carmo @rcarmo


Patches and Suggestions
========

- Marcelo Alaniz
- Margarita Manterola
- Gerardo Allende
- Darell Tan
- Alan Etkin
- Richard Jones
- matee <matee@matee.net>
- Yuan Liu
- Pat Kujawa
- Alfredo Saglimbeni <a.saglimbeni@scsitaly.com> @asaglimbeni
- Jor S
- Akram Parvez
- beppler
- Remco Boerma
- Sergei Lemeshkin
- Tim Alexander
- Ralf Henschkowski
- Allan Crooks
- Paul Jimenez
- Jonathan Balsano
- Kevin Bullmann
- Pedro Hdez
- jpc <jpc@alumni.rice.edu>
- Luka Birsa
- Bill Bennert @billwebreply
- Sean E. Millichamp
