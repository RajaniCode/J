module Savon
  VERSION = '2.11.1'
end
