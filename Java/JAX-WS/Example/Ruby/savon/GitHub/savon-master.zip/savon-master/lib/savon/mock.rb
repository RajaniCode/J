module Savon
  class ExpectationError < StandardError; end
end

require "savon/mock/expectation"
